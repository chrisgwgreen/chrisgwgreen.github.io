class lazy {

  constructor() {
    this.fns = [];
  }

  add() {
    this.fns.push(Array.prototype.slice.call(arguments));
  }

  evaluate(values) {

    let i = 0;

    for(; i < values.length; i++) {

      this.fns.forEach(fn => {

          values[i] = fn[0].apply(null, [values[i], ...fn.slice(1)]);

      });

    }

    return values;

  }

};

module.exports = lazy

const Lazy = require('./lazy');

test('Basic Math.sqrt', () => {

    const test = new Lazy();

    test.add(Math.sqrt);

    expect(test.evaluate([9,4,1])).toEqual([3,2,1]);

});

test('Basic Addition', () => {

    const test = new Lazy();

    test.add((a, b) => {
      return a + b;
    }, 1);

    expect(test.evaluate([1,2,3])).toEqual([2,3,4]);

});

test('Combination', () => {

    const test = new Lazy();

    test.add(Math.sqrt);
    test.add((a, b) => {
      return a + b;
    }, 1);

    expect(test.evaluate([9,4,1])).toEqual([4,3,2]);

});
